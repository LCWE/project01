CREATE VIEW view_student_result AS
  SELECT
    `db2`.`student`.`studentName`       AS `姓名`,
    `db2`.`subject`.`subjectName`       AS `课程名称`,
    avg(`db2`.`result`.`studentResult`) AS `平均成绩`
  FROM ((`db2`.`student`
    JOIN `db2`.`subject` ON ((`db2`.`student`.`gradeID` = `db2`.`subject`.`gradeID`))) JOIN `db2`.`result`
      ON ((`db2`.`student`.`studentNo` = `db2`.`result`.`studentNo`)))
  GROUP BY `db2`.`student`.`studentName`;

